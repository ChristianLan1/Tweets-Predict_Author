import test_set_read
import nltk
import re
import pdb
from nltk.tokenize import TweetTokenizer
from nltk.tokenize import PunktSentenceTokenizer


def wordCount(tweet):
    '''
    This method counts two features wrt number of words in tweet:
    1. count the total number of words in tweets, and write the word in corresponding file
    2. count the number of different words in tweets, and write the word in corresponding file
    :param tweet:
    :return: ([total words], number of total words, [different words], number of words)
    '''
    wordFormat = re.compile('^[A-Za-z]+$')
    totalWord = []
    length = 0
    uniqueWord = []
    numberOfWord = 0
    numberOfchar = 0
    for item in tweet:
        if re.match(wordFormat, item) != None:
            totalWord.append(item)
            length += 1
            numberOfchar += len(item)
            if item not in uniqueWord:
                uniqueWord.append(item)
                numberOfWord += 1

    return (totalWord, length, uniqueWord, numberOfWord, numberOfchar)


def allCapital(tweet):
    '''
    this methods count the number of all capital word in tweet and return the word and number
    :param tweet:
    :return: (capitalWord, number)
    '''
    wordFormat = re.compile('^[A-Z]{2,}$')
    capitalWord = []
    # captialWord = ''
    number = 0

    for item in tweet:
        if re.match(wordFormat, item) != None and item != 'RT':
            capitalWord.append(item)
            # captialWord += ' ' + item
            number += 1

    # print('allCapital')
    # print(str(capitalWord) + ' '+ str(number))
    return (capitalWord, number)

def punctuation(tweet):
    '''
    this method counts of the special or repeated punctuations such as '!!!!!'
    :param tweet:
    :return: (punctuation, number)
    '''
    format = re.compile('^[!?.,*~%^&]{2,}$')
    punc = []
    number = 0
    for item in tweet:
        if re.match(format, item) != None and item != 'LOL':
            punc.append(item)
            number += 1
    # print('this is repeated punctuation')
    # print(str(punc) + ' ' + str(number))
    return (punc, number)


def atSomeone(tweet):
    '''
    this method counts the format like '@Jennie'
    :param tweet:
    :return: (@someone, number)
    '''
    # format = re.compile('^@[\w]+$')
    someone = []
    number = 0
    for i in range(0, len(tweet)-1):
        # pdb.set_trace()
        if tweet[i] == '@' and tweet[i+1] != None and (i-1 ==-1 or tweet[i-1] != 'RT'):
        # if re.match(format, item) != None:
            someone.append(tweet[i] + tweet[i+1])
            number += 1
    # print('this is someone')
    # print(str(someone) + ' ' + str(number))
    return (someone, number)


def hashtag(tweet):
    '''
    this method counts the format like '#Jennie'
    :param tweet:
    :return: (#something, number)
    '''
    # format = re.compile('^#[\w]+$')
    hashtag = []
    number = 0
    # for item in tweet:
    #     if re.match(format, item) != None:
    #         hashtag.append(item)
    #         number += 1
    for i in range(0, len(tweet)-1):
        if tweet[i] == '#' and tweet[i+1] != None:
            hashtag.append(tweet[i] + tweet[i+1])
            number += 1
    # print('this is hashtag')
    # print(str(hashtag) + ' ' + number)
    return (hashtag, number)

def retweet(tweet):
    '''
    this method is to record those retweet feature
    :param tweet:
    :return: (retweet, number)
    '''
    retweet = []
    number = 0
    for i in range(0, len(tweet) - 2):
        if tweet[i] == 'RT' and tweet[i+1] == '@':
            retweet.append(tweet[i] + tweet[i+1] + tweet[i+2])
            number += 1
    # print('this is retweet')
    # print(str(retweet) + ' ' + str(number))
    return retweet, number

def singlePuncNumber(tweet):
    '''
    this method counts the total number of single punctuation such as '.,?!'
    :param tweet: a list
    :return: (single_punctuation, number)
    '''
    format = re.compile('^[\W]$')
    punctuation = []
    number = 0
    for item in tweet:
        if re.match(format, item) != None:
            punctuation.append(item)
            number += 1

    return (punctuation, number)

def tweetToken(tweet):
    '''
    this method uses tweetTokenizer from nltk, a list of all the features in a tweet
    :param tweet: a String
    :return: (author, list of features)
    '''
    tknzr = TweetTokenizer(strip_handles=True, reduce_len=True)
    features = tknzr.tokenize(tweet)
    author = features[0]
    feature = features[1:]
    return author, feature


def senWithEmoji(tweet):
    '''
    this method is to find whether the tweet has the pattern like "this is a good day :D", and it will return a boolean
    value of true or false
    :param tweet: a list of preprocessed tweet
    :return: number of emoji in a tweet
    '''
    emoji = re.compile('[:|=|;]{1}[-]{0,1}[D|)|(|O]|lol|LOL')
    number = 0
    for token in tweet:
        if re.match(emoji, token) != None:
            number += 1
        # print('this is emoji')
        # print(str(emoji) + ' ' + str(number))
    return number

def sentInTweet(tweet):
    '''
    this method returns the number of sentences in a tweet
    :param tweet: input should be a String rather than a pre-processed list
    :return: number of sentences
    '''
    sens = nltk.sent_tokenize(tweet)
    length = len(sens)
    return length

def repeatedLetter(tweet):
    '''
    this methods is to calculate the number of words like 'cooooool'
    :param tweet: a list of tokens
    :return: number
    '''
    number = 0
    format = re.compile('(?:[\w]){3,}',)
    letter = re.compile('^[A-Za-z]$')
    for token in tweet:
        if re.match(format, token) != None and re.match(letter, token) != None:
            number += 1
            # print('this is repeated letter')
            # print(str(token) + ' ' + str(number))

    return number

def appearOfNum(tweet):
    '''
    this method counts the appearance of number
    :param tweet:
    :return: number
    '''
    number = 0
    format = re.compile('^[0-9]+$')
    for token in tweet:
        if re.match(format, token) != None:
            number += 1

    return number


def formatOfDate(tweet):
    '''
    this method finds the date and counts the number
    :param tweet:
    :return: number
    '''
    number = 0
    format = re.compile('[0-9]{2,4}-[0-9]{,2}-[0-9]{,2}')
    for token in tweet:
        if re.match(format, token) != None:
            number += 1
            # print('this is format date')
            # print(str(token) + ' ' + str(number))
    return number



