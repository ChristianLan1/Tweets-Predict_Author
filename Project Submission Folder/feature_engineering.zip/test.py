import feature_engineering as fe
import test_set_read as tsr
from sklearn.feature_extraction.text import CountVectorizer
import numpy as np
import pdb

def feature_integration(dataset):
    '''
    this methods extract the all-capital words, @someone, #something, and convert these features into a np array
    :param dataset:
    :return: (X, Y)
    '''
    features = []
    Y = []
    for (author, tweet) in dataset:
        featureInTweet = ''
        someone, sNumber = fe.atSomeone(tweet)
        hashtag, hNumber = fe.hashtag(tweet)
        capitalWord, cNumber = fe.allCapital(tweet)

        for sb in someone:
            featureInTweet += ' ' + sb

        for sth in hashtag:
            featureInTweet += ' ' + sth

        for cap in capitalWord:
            featureInTweet += ' ' + cap

        features.append(featureInTweet)
        Y.append(author)

    vectorizer = CountVectorizer(min_df=1)
    # X = vectorizer.fit_transform(features)
    X = features

    return (X, Y)


def feature_integration01(dataset):
    '''
    this methods extract the all-capital words, @someone, #something, and convert these features # of word, # of punctuation
    :param dataset:
    :return: (X, Y)
    '''
    features = []
    Y = []
    for (author, tweet) in dataset:
        featureInTweet = ''
        someone, sNumber = fe.atSomeone(tweet)
        hashtag, hNumber = fe.hashtag(tweet)
        capitalWord, cNumber = fe.allCapital(tweet)
        totalWords, totalNumber, diffWords, numOfWords, numOfChar = fe.wordCount(tweet)
        punctuation, pNumber = fe.punctuation(tweet)

        for sb in someone:
            featureInTweet += ' ' + sb

        for sth in hashtag:
            featureInTweet += ' ' + sth

        for cap in capitalWord:
            featureInTweet += ' ' + cap
        featureInTweet += ' ' + str(cNumber) + ' ' + str(numOfWords) + ' ' + str(numOfChar) + ' ' + str(pNumber)
        features.append(featureInTweet)
        Y.append(author)

    vectorizer = CountVectorizer(min_df=1)
    # X = vectorizer.fit_transform(features)
    X = features

    return (X, Y)

def feature_integration02(dataset):
    '''
    this methods extract the all-capital words, @someone, #something, and convert these features # of word, # of punctuation
    , compared with 01 version, it sets range for number of features, 0 for 0, 1 for 1-4, 2 for 5-8, 3 for 9-11, 4 for 11-14,
    5 for > 15
    since # of character/# of word is basically in 3-7 range, and it sparses among authors, hence I do not think it is a
    useful feature, thus I abandon it in this version. Also, number of punctuation is clustered in 0-3 range, I just keep
    this feature in this version
    :param dataset:
    :return: (X, Y)
    '''
    features = []
    Y = []
    for (author, tweet) in dataset:
        featureInTweet = ''
        someone, sNumber = fe.atSomeone(tweet)
        hashtag, hNumber = fe.hashtag(tweet)
        capitalWord, cNumber = fe.allCapital(tweet)
        totalWords, totalNumber, diffWords, numOfWords, numOfChar = fe.wordCount(tweet)
        punctuation, pNumber = fe.punctuation(tweet)

        for sb in someone:
            featureInTweet += ' ' + sb

        for sth in hashtag:
            featureInTweet += ' ' + sth

        for cap in capitalWord:
            featureInTweet += ' ' + cap

        if cNumber == 0:
            cn = 0
        elif cNumber > 0 and cNumber <= 4:
            cn = 1
        elif cNumber > 4 and cNumber <= 8:
            cn = 2
        elif cNumber > 8 and cNumber <= 11:
            cn = 3
        elif cNumber > 11 and cNumber <= 14:
            cn = 4
        else:
            cn = 5
        featureInTweet += ' ' + str(cn) + ' ' + str(pNumber)
        features.append(featureInTweet)
        Y.append(author)

    vectorizer = CountVectorizer(min_df=1)
    # X = vectorizer.fit_transform(features)
    X = features

    return (X, Y)

def feature_integration03(dataset):
    '''
    this methods extract the all-capital words, @someone, #something, and convert these features # of word, # of punctuation
    , compared with 01 version, it sets range for number of features, 0 for 0, 1 for 1-4, 2 for 5-8, 3 for 9-11, 4 for 11-14,
    5 for > 15
    since # of character/# of word is basically in 3-7 range, and it sparses among authors, hence I do not think it is a
    useful feature, thus I abandon it in this version. Also, number of punctuation is clustered in 0-3 range, I just keep
    this feature in this version
    :param dataset:
    :return: (X, Y)
    '''
    features = []
    Y = []
    for (author, tweet) in dataset:
        featureInTweet = ''
        someone, sNumber = fe.atSomeone(tweet)
        hashtag, hNumber = fe.hashtag(tweet)
        capitalWord, cNumber = fe.allCapital(tweet)
        totalWords, totalNumber, diffWords, numOfWords, numOfChar = fe.wordCount(tweet)
        punctuation, pNumber = fe.punctuation(tweet)

        for sb in someone:
            featureInTweet += ' ' + sb

        for sth in hashtag:
            featureInTweet += ' ' + sth

        for cap in capitalWord:
            featureInTweet += ' ' + cap

        if cNumber == 0:
            cn = 0
        elif cNumber > 0 and cNumber <= 4:
            cn = 1
        elif cNumber > 4 and cNumber <= 8:
            cn = 2
        elif cNumber > 8 and cNumber <= 11:
            cn = 3
        elif cNumber > 11 and cNumber <= 14:
            cn = 4
        else:
            cn = 5

        features.append(featureInTweet)
        Y.append(author)

    vectorizer = CountVectorizer(min_df=1)
    # X = vectorizer.fit_transform(features)
    X = features

    return (X, Y)


def feature_integration04():
    file = open('./train_tweets.txt', 'r', encoding='utf-8')
    line = file.readline()
    print(line)
    split = fe.tweetToken(line)
    print(split)

    file.close()


def structure(dataset):
    '''
    this method is to learn the structure feature of the tweet
    :param tweet:
    :return: length of the sentence, number of all capital word, number of @, number of retweet, total number of words,
             continuous punctuation, 'coooool', appearance of digits, date
    '''
    structure = []
    Y = []

    for (author, tweet) in dataset:
        Y.append(author)
        format = []
        originTweet = ''
        for token in tweet:
            originTweet = originTweet + token + ' '

        numOfSent = fe.sentInTweet(originTweet)
        format.append(numOfSent)
        _, numOfCap = fe.allCapital(tweet)
        # format.append(numOfCap)
        # _, numOfAt = fe.atSomeone(tweet)
        # format.append(numOfAt)
        # _, numOfRetweet = fe.retweet(tweet)
        # format.append(numOfRetweet)
        _, lenOfWords, _, diffWords, numOfChar = fe.wordCount(tweet)
        # # average-word-length
        if lenOfWords != 0:
            format.append(numOfChar/lenOfWords)
        else:
            format.append(0)
        #
        # average-sentence-length
        format.append(lenOfWords/numOfSent)
        # numOfRepeat = fe.repeatedLetter(tweet)
        # format.append(numOfRepeat)
        appearOfNum = fe.appearOfNum(tweet)
        format.append(appearOfNum)
        # numOfDate = fe.formatOfDate(originTweet)
        # format.append(numOfDate)

        # upper-chars-ratio
        if lenOfWords != 0:
            format.append(numOfCap/lenOfWords)
        else:
            format.append(0)

        # type-token-ratio
        if lenOfWords != 0:
            format.append(diffWords/lenOfWords)
        else:
            format.append(0)

        # vocabulary richness
        format.append(diffWords)

        structure.append(format)

    return structure, Y



def create_train_feature(dataset):
    feature = open('./feature.txt', 'w')
    # for token in dataset:
    for (author, tweet) in dataset:
        totalWords, totalNumber, diffWords, numOfWords, numOfChar = fe.wordCount(tweet)
        capitalWord, cNumber = fe.allCapital(tweet)
        punctuation, pNumber = fe.punctuation(tweet)
        someone, sNumber = fe.atSomeone(tweet)
        hashtag, hNumber = fe.hashtag(tweet)
        # pdb.set_trace()
        singlePunc, singleNumber = fe.singlePuncNumber(tweet)
        feature.writelines([author, ' ', str(totalNumber), ' ', str(numOfWords), ' ', str(numOfChar), ' ', str(cNumber),
                            ' ', str(pNumber), ' ', str(singleNumber)])
        for sb in someone:
            feature.writelines([' ', sb])

        for hash in hashtag:
            feature.writelines([' ', hash])
        feature.write('\n')
    feature.close()

def printFeatures(dataset):
    print = open('./print01.txt', 'w')
    print.write(' this file is to record the emoji in tweet')
    for (author, tweet) in dataset:
        boolean = fe.senWithEmoji(tweet)
        print.writelines([author, ' ', str(boolean) + '\n'])
        # totalWords, totalNumber, diffWords, numOfWords, numOfChar = fe.wordCount(tweet)
        # capitalWord, cNumber = fe.allCapital(tweet)
        # punctuation, pNumber = fe.punctuation(tweet)
        #
        # if totalNumber != 0:
        #     print.writelines([author, ' ', str(numOfChar/totalNumber), ' ', str(cNumber), ' ', str(pNumber), '\n'])
        # else:
        #     print.writelines([author, ' ', str(0), ' ', str(cNumber), ' ', str(pNumber), '\n'])

    print.close()


def extract_features(my_docs):
    totalWordsFile = open('./total_words.txt', 'w')
    totalNumberFile = open('./total_number.txt', 'w')
    uniqueWordsFile = open('./unique_words.txt', 'w')
    wordCountFile = open('./word_count.txt', 'w')
    allCapitalFile = open('./all_capital_word.txt', 'w')
    numberOfCharFile = open('./number_of_character.txt', 'w')
    numberOfCapital = open('./number_of_capital.txt', 'w')

    for (author, tweet) in my_docs:
        totalWords, totalNumber, diffWords, numOfWords, numOfChar = fe.wordCount(tweet)
        capitalWord, cNumber = fe.allCapital(tweet)
        totalWordsFile.write(author)
        totalNumberFile.write(author)
        uniqueWordsFile.write(author)
        wordCountFile.write(author)
        allCapitalFile.write(author)
        numberOfCharFile.write(author)
        numberOfCapital.write(author)
        for t in totalWords:
            totalWordsFile.writelines([' ', t])
        totalWordsFile.writelines('\n')
        totalNumberFile.writelines([' ', str(totalNumber), '\n'])
        for d in diffWords:
            uniqueWordsFile.writelines([' ', d])
        uniqueWordsFile.write('\n')
        wordCountFile.writelines([' ', str(numOfWords), '\n'])
        for a in capitalWord:
            allCapitalFile.writelines([' ', a])
        allCapitalFile.write('\n')
        numberOfCharFile.writelines([' ', str(numOfChar), '\n'])
        numberOfCapital.writelines([' ', str(cNumber), '\n'])

    totalWordsFile.close()
    totalNumberFile.close()
    uniqueWordsFile.close()
    wordCountFile.close()
    allCapitalFile.close()
    numberOfCharFile.close()
    numberOfCapital.close()


    # for i in range(0, 10):
    #     author, tweet = train_set[i]
    #     word = fe.wordCount(tweet)
    #     print(word)


def preFeatures(dataset):
    numOfAllWords = []
    numOfUniWords = []
    numOfChar = []
    numOfCapWords = []
    allCapWords = []  # list of String
    numOfPunc = []
    someone = []
    something = []
    author = []

    for auth, tweet in dataset:
        totalWord, length, uniqueWord, numberOfWord, numberOfchar = fe.wordCount(tweet)
        numOfAllWords.append((length))
        numOfUniWords.append((numberOfWord))
        numOfChar.append((numberOfchar))

        capitalWord, number = fe.allCapital(tweet)
        numOfCapWords.append((number))
        cap = ''
        if len(capitalWord) < 2:
            allCapWords.append(' ')
        else:
            for word in capitalWord:
                cap = cap + word + ' '
            allCapWords.append(cap)

        punc, pNumber = fe.punctuation(tweet)
        numOfPunc.append((pNumber))

        sb, sbNumber = fe.atSomeone(tweet)
        b = ''
        for anyone in sb:
            b = b + anyone + ' '
        someone.append(b)

        sth, sthNumber = fe.hashtag(tweet)
        t = ''
        for thing in sth:
            t = t + thing + ' '
        something.append(t)

        author.append(auth)

    return numOfAllWords, numOfUniWords, numOfChar, numOfCapWords, allCapWords, numOfPunc, someone, something, author

def features(dataset):
    '''
    the imput is raw tweet
    :param tweet:
    :return:
    '''
    emoji = []
    numOfSent = []
    Y = []

    for tweet in dataset:
        author, feature = fe.tweetToken(tweet)

        if fe.senWithEmoji(feature):
            emoji.append(1)  # this tweet contains emoji symbol
        else:
            emoji.append(0)

        Y.append(author)
        sentence = fe.sentInTweet(tweet)
        numOfSent.append((sentence))

    return emoji, numOfSent, Y



if __name__ == "__main__":
    my_docs = tsr.Read_from_TestSet()
    # test_set,train_set = tsr.create_set_test_train(my_docs)
    # create_train_feature(my_docs[0:100])
    # printFeatures(my_docs)
    # print('this is test for feature integration')
    # feature_integration04()