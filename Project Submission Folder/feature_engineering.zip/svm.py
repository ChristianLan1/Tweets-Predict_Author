from sklearn import svm
from matplotlib import pyplot as plt
import test_set_read as tsr
import test
# from sklearn.cross_validation import cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import LinearSVC
from sklearn.metrics import accuracy_score
import numpy as np
import pdb
import feature_engineering as fe
import matplotlib.pyplot as plt


def linear_svc(trainX, trainY, testX, testY):
    clf = LinearSVC(max_iter=100000)
    clf.fit(trainX, trainY)
    predictY = clf.predict(testX)
    print('this is the result of linear svm: ')
    accuracy = accuracy_score(predictY, testY)
    print(accuracy)
    print(clf.coef_)
    return accuracy

def svm_classifier(trainX, trainY, testX, testY):
    clf_linear = svm.SVC(C=1.0, kernel='linear')
    clf_poly = svm.SVC(C=1.0, kernel='poly', degree=3)
    clf_rbf = svm.SVC(C=1.0, kernel='rbf', gamma=0.5, max_iter=100000)

    plt.figure(figsize=(10, 10), dpi=144)

    print('Start fitting')
    clf_linear.fit(trainX, trainY)
    clf_rbf.fit(trainX, trainY)
    print('Finish fitting')
    print(testX[0:100])
    predictY = clf_linear.predict(testX)
    predictY = clf_rbf.predict(testX)

    print(accuracy_score(testY, predictY))
    score = clf_linear.score(testX, testY)
    print('the score of linear svm is {}'.format(score))

    clfs = [clf_linear, clf_poly, clf_rbf]
    clfs = [clf_linear]

    # titles = ['Linear Kernel', 'Polynomial Kernel', 'Gaussian Kernel']
    titles = ['Linear Kernel']

    for clf, i in zip(clfs, range(len(clfs))):
        clf.fit(trainX, trainY)
        print("{}'s score:{}".format(titles[i], clf.score(trainX,trainY)))
        out = clf.predict(trainX)
        print("out's shape:{}, out:{}".format(out.shape, out))
        score = clf.score(testX, testY)


def single_feature():
    my_docs = tsr.Read_from_TestSet()

    test_set,train_set = tsr.create_set_test_train(my_docs[0: 11000])

    numOfAllWords, numOfUniWords, numOfChar, numOfCapWords, allCapWords, numOfPunc, someone, something, trainY = test.preFeatures(train_set)
    allWordsTest, uniWordsTest, charTest, capWordsTest, allCapTest, puncTest, sbTest, sthTest, testY = test.preFeatures(test_set)

    # trainTweets = train_set[0:12000]

    # X, trainY = test.feature_integration(trainTweets)
    # tX, testY = test.feature_integration(test_set)

    # X, trainY = test.feature_integration03(train_set)
    # tX, testY = test.feature_integration03(test_set)


    countVectorizer = CountVectorizer()

    print('the training set is of size 10000, and the test set is 1000')
    #
    # print('this is feature number of all words in a tweet: ')
    # # numOfAllWords = np.array(numOfAllWords).reshape(-1,1)
    # # allWordsTest = np.array(allWordsTest).reshape(-1,1)
    # linear_svc(np.array(numOfAllWords).reshape(-1,1), trainY, np.array(allWordsTest).reshape(-1,1), testY)
    #
    # print('this is feature number of unique words in a tweet: ')
    # linear_svc(np.array(numOfUniWords).reshape(-1,1), trainY, np.array(uniWordsTest).reshape(-1,1), testY)



    # print('this is the number of all capital words in a tweet: ')
    # linear_svc(np.array(numOfCapWords).reshape(-1,1), trainY, np.array(capWordsTest).reshape(-1,1), testY)

    print('this is the capital words in a tweet: ')
    trainX = countVectorizer.fit_transform(allCapWords)
    testX = countVectorizer.transform(allCapTest)
    linear_svc(trainX, trainY, testX, testY)

    # print('this is the number of punctuation: ')
    # linear_svc(np.array(numOfPunc).reshape(-1,1), trainY, np.array(puncTest).reshape(-1,1), testY)
    #
    # print('this is the number of letters in a tweet: ')
    # linear_svc(np.array(numOfChar).reshape(-1,1), trainY, np.array(charTest).reshape(-1,1), testY)

    # print('this is at someone: ')
    # sbTrain = countVectorizer.fit_transform(someone)
    # sbtest = countVectorizer.transform(sbTest)
    # linear_svc(sbTrain, trainY, sbtest, testY)
    #
    # print('this is hashtag')
    # sthTrain = countVectorizer.fit_transform(something)
    # sthtest = countVectorizer.transform(sthTest)
    # linear_svc(sthTrain, trainY, sthtest, testY)


    # file = open('./train_tweets.txt', 'r', encoding='utf-8')
    # lines = []
    # for _ in range(0,10000):
    #     line = file.readline()
    #     lines.append(line)
    #
    # test_set,train_set = tsr.create_set_test_train(lines)
    # file.close()
    #
    # emojiTrain, sentTrain, trainY = test.features(train_set)
    # emojiTest, sentTest, testY = test.features(test_set)
    #
    # print('this is emoji: ')
    # # sbTrain = countVectorizer.fit_transform(emojiTrain)
    # # sbtest = countVectorizer.transform(emojiTest)
    # linear_svc(np.array(emojiTrain).reshape(-1,1), trainY, np.array(emojiTest).reshape(-1,1), testY)
    #
    # print('this is number of sentence: ')
    # # sthTrain = countVectorizer.fit_transform(something)
    # # sthtest = countVectorizer.transform(sthTest)
    # linear_svc(np.array(sentTrain).reshape(-1,1), trainY, np.array(sentTest).reshape(-1,1), testY)



if __name__ == '__main__':
    my_docs = tsr.Read_from_TestSet()

    pic = []
    xx = []
    yy = []
    plt.rcParams['figure.dpi'] = 128
    for size in range(110, 110000, 550):
        test_set,train_set = tsr.create_set_test_train(my_docs[0: size])

        trainX, trainY = test.structure(train_set)
        testX, testY = test.structure(test_set)

        trainX = np.array(trainX)
        testX = np.array(testX)

        accuracy = linear_svc(trainX, trainY, testX, testY)
        pic.append((size * (10/11), accuracy))

        xx.append(size * (10/11))
        yy.append(accuracy)
    x = np.array(xx)
    y = np.array(yy)
    plt.plot(x, y, label = 'accuracy on different size of data set')
    plt.xlabel('dataset')
    plt.ylabel('accuracy')
    plt.legend()
    plt.show()

